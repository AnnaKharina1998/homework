import scipy.io as sio
import numpy as np

def get_signal_slice(s_input, s_output, axis_in, axis_out, start, shift):
    m = sio.loadmat(s_input)
    skl_arr = m.get('sigKL')
    sign = np.array(list(map(lambda x: x[0], skl_arr)))
    final_array = sign[start:start+shift]
    sio.savemat(s_output, {axis_out: final_array})
    return True
