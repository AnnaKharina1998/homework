import os.path
import scipy.io as sio
from scipy import signal
import matplotlib.pyplot as plt
import get_signal_slice as gss

if __name__ == '__main__':
    # Возьмём участок спектра с 3 секунд, что соответствует 6210628 элементу массива,
    # вычисленному отдельным скриптом. Поэтому нет необходимости более считывать масссив времени
    # Зная, что частота оцифровки сигнала 2 МГц, время между точками 0.5 микро секунд,
    # Необходимые нам 50мс будут лежать в следующем срезе массива
    # Загрузим этот участок сигнала в отдельный файл для быстрой работы с ним.
    # Если такой файл уже есть, заново брать сигнал не будем:
    slice_filename = 'spectr50ms.mat'
    if not os.path.isfile(slice_filename):
        gss.get_signal_slice('33484K-LFS.mat', slice_filename, 'sigKL', 'data', 6210628, 2000000)
    spectr = sio.loadmat(slice_filename).get('data')[0]

    # simple self-correlation:
    # Вызовем метод полной корреляции сигнала самим с собой и возьмём первые 10000 точек.
    # Сохраним в файл.
    # Если файл уже есть, заново считать не будем
    if not os.path.isfile('simple_crossself.mat'):
        full_corr = signal.correlate(spectr, spectr, mode='full')
        goal_corr = full_corr[int(len(full_corr)/2):][:10000]
        sio.savemat('simple_crossself.mat', {"data": goal_corr})

    # Для проверки корректности предыдущих расчётов посчитаем автокорреляцию вручную:
    # Для этого рассчитаем корреляцию сигнала и сигнала сдвинутого на i от 1 до 10000
    # И запишем в массив нулевое значение результата
    # Если файл уже есть, заново считать не будем (время расчётов около 3 часов)
    if not os.path.isfile('tenthousands.mat'):
        a = []
        for i in range(10000):
            corr = signal.correlate(spectr[0:-10000], spectr[i:i-10000], mode='full')
            corr2 = corr[int(len(corr)/2):][0]
            a.append(corr2)
        sio.savemat('tenthousands.mat', {"data": np.array(a, dtype=np.float64)})

    # Построим оба графика: простой и результат долгих расчётов:
    manual_corr = sio.loadmat('tenthousands.mat').get('data')[0]
    simple_corr = sio.loadmat('simple_crossself.mat').get('data')[0]
    plt.plot(simple_corr)
    plt.plot(manual_corr)
    plt.show()


